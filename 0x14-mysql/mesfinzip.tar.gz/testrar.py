#!usr/bin/python3
from sys import argv

text = argv[1]
print(text)
